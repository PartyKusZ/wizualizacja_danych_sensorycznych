var searchData=
[
  ['insert_5f_238',['INSERT_',['../classDatabase.html#a4f7f2184c023569222683beafa883a64',1,'Database']]]
];
