var searchData=
[
  ['data_227',['data',['../classDatabase.html#a45054f25770838487b23f5c148e3182b',1,'Database::data()'],['../classDb__data.html#a7f63c4277976b816d12e206ce51f484f',1,'Db_data::data()'],['../classMain__window.html#a720cace912632ed2475867e5f95cc728',1,'Main_window::data()']]],
  ['date_5fstart_228',['date_start',['../classHistorical__data.html#aa3d0a4754baaf103b8c256842552064a',1,'Historical_data']]],
  ['date_5fstop_229',['date_stop',['../classHistorical__data.html#a314d3e9a82ed2b2304e4bdcc147f067a',1,'Historical_data']]],
  ['db_230',['db',['../classDatabase.html#ab863759c5f56be3683aaa4797c0fc9e6',1,'Database::db()'],['../classHistorical__data.html#a6bf637066e9f0f28141f2edb1cc7fd7e',1,'Historical_data::db()']]],
  ['db_5fdata_231',['db_data',['../classHistorical__data.html#a2d65909c606b4cf635a7cf99a479a20d',1,'Historical_data']]]
];
