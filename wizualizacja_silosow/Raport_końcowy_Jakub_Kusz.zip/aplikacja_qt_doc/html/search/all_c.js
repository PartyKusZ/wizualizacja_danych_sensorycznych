var searchData=
[
  ['qdate_5fto_5fdb_5fformat_58',['qdate_to_db_format',['../classHistorical__data.html#a6d060c307917e47d3c32131674a2d06d',1,'Historical_data']]]
];
