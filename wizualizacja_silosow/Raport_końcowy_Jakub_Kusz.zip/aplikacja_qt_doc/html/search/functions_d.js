var searchData=
[
  ['update_211',['update',['../classDatabase.html#ac7ed676152c64ea702340156bd7781cf',1,'Database']]]
];
