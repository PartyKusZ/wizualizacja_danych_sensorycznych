var searchData=
[
  ['regexes_247',['regexes',['../classDatabase.html#a5a631e3ddee0ff86b6c9a8d0b345c71e',1,'Database']]]
];
