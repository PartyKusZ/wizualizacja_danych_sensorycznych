var searchData=
[
  ['paths_245',['PATHS',['../classPort__error.html#a1adb6c653c58d86663a38eb27a80f7f2',1,'Port_error']]],
  ['port_246',['port',['../classPort__error.html#a34b7dba2d380724f1af9fc93d3ded102',1,'Port_error']]]
];
