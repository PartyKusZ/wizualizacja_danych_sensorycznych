var searchData=
[
  ['colors_5finterpolation_7',['colors_interpolation',['../classHum__draw.html#a30d7be805b3b914ce7c1454a585dbfc3',1,'Hum_draw::colors_interpolation()'],['../classTemp__draw.html#a88492b424b0b7db1090b7170ef681743',1,'Temp_draw::colors_interpolation()']]]
];
