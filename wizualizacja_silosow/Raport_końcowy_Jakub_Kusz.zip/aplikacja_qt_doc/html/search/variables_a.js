var searchData=
[
  ['temp_5f1_253',['temp_1',['../classAll__param__draw.html#a9a05379a1b352ea79f5242292849202c',1,'All_param_draw']]],
  ['temp_5f2_254',['temp_2',['../classAll__param__draw.html#a95ea5d1416f0f0bb5dd035a885eeb1ce',1,'All_param_draw']]],
  ['timer_255',['timer',['../classDatabase.html#a4dce9da232cac4f875bfec4ab9953a80',1,'Database::timer()'],['../classMain__window.html#a162e816c3881828fb4df98372d6ab2bd',1,'Main_window::timer()']]]
];
