var searchData=
[
  ['ui_256',['ui',['../classAll__param__backend.html#a0a2728d9657e715d7c54aca8873c1361',1,'All_param_backend::ui()'],['../classHistorical__data.html#a6bd3006d14a1c9470f676756064db316',1,'Historical_data::ui()'],['../classHum__backend.html#af9cf21b349026156994b45b2a7910900',1,'Hum_backend::ui()'],['../classTemp__backend.html#a1834a45c84570fe5f8a48f4993565d27',1,'Temp_backend::ui()'],['../classVol__backend.html#ac7094e61867590ab7d4d4f2db1a1830f',1,'Vol_backend::ui()']]]
];
