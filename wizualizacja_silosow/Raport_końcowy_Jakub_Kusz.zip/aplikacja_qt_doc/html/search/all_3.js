var searchData=
[
  ['error_5fmsg_22',['error_msg',['../classDatabase.html#ab08e9af5a75bdd6afbcecbffc21da4b5',1,'Database']]]
];
